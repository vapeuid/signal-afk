# Signal AFK v2

Headless multi-account Minecraft client with a phone dashboard.
Adds to v1: **chat/commands, manual movement, live inventory (drop + rearrange),
view-only minimap, add/remove accounts, per-account server swap, and a
Disconnect button that frees an account so you can log in on your PC.**

## What each tab does (per account)

- **Move** — hold the arrows to walk, ⤒ to jump, Sneak, Sprint toggle, Turn L/R.
  "Stop moving" releases everything. Anti-AFK jiggle keeps you from being kicked
  when idle (auto-pauses while you're holding a control).
- **Chat** — live chat log + a box to type any message or `/command`
  (e.g. `/warp base`, `/pay`, `/msg`). Quick buttons for `/afk /spawn /warp /home`.
- **Items** — live inventory with textures. Tap an item, then tap an empty slot to
  move it; or use **Drop 1 / Drop all**. Updates automatically when you pick things up.
- **Map** — top-down view of the blocks around you with a facing marker. Tap **Scan**
  to refresh ("see where I am"). View only — it does not move you.

Per card you also get: **Swap** (change that account's server host and rejoin),
**Disconnect (free acct)** (fully leaves the server so you can log in on your PC —
won't auto-reconnect until you press **Reconnect**), **Rejoin**, and **Remove**.

Add accounts from the form at the bottom. First login for a new account prints a
device-code link in `pm2 logs` — approve it once at microsoft.com/link.

## Deploy on the VPS

```bash
cd ~/signal-afk           # or wherever you cloned it
git pull                  # if using a git repo
npm install
cp config.example.json config.json   # first time only
nano config.json          # set host, dashboardPassword, accounts
pm2 restart signal-afk || pm2 start src/index.js --name signal-afk
pm2 save
```

Dashboard: `http://<vps-ip>:3000` — enter the dashboard password.

## config.json

- `settings.host/port/version` — default server for all accounts.
- `settings.dashboardPassword` — required to open the dashboard.
- Each account may override `host`/`port`/`version` for a per-account server.
- Accounts you add/remove from the UI are saved back to config.json automatically.

Requires Node 18+. Deps: mineflayer, socket.io, express, minecraft-assets.
